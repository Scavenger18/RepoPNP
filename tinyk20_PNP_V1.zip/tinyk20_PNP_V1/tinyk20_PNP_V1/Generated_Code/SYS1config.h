/**
 * \file
 * \brief Configuration header file for SeggerSystemView
 *
 * This header file is used to configure settings of the Segger SystemView module.
 */
#ifndef __SYS1_CONFIG_H
#define __SYS1_CONFIG_H

/* no configuration supported yet */

#endif /* __SYS1_CONFIG_H */
