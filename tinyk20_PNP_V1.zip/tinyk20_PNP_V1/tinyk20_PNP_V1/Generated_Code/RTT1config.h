#ifndef __RTT1_CONFIG_H
#define __RTT1_CONFIG_H

/* no configuration supported yet */

#endif /* __RTT1_CONFIG_H */
