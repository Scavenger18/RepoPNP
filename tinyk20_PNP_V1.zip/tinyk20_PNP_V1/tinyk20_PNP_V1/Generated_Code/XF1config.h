#ifndef __XF1_CONFIG_H
#define __XF1_CONFIG_H

#ifndef XF1_CONFIG_XCFG_FORMAT_FLOAT
  #define XF1_CONFIG_XCFG_FORMAT_FLOAT  0 /* 1: enable, 0: disable floating format (component property) */
#endif

#endif /* __XF1_CONFIG_H */
